import java.util.Random;
import java.util.ArrayList;
public class Trump {
	
String trump1;
String trump2;

double ran1 = Math.random();
}
