/*import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
public class Trump extends Blackjack{
	
String trump;
public static int generateBetween(){
   	Random random = new Random();
    int generated = random.nextInt(7);
    return generated; 
    
}
public static void trumpPick(){
	super(HP);
	String Card;
	int Health;
	if (generateBetween() == 0){
		Health = HP + 50;
		Card = "Equal playing grounds";
		return;
	}
	
}
}*/

