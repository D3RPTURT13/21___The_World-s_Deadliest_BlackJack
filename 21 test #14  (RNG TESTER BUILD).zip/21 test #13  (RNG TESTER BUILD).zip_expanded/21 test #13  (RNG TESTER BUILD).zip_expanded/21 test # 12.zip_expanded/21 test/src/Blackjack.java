import java.util.Scanner;
import java.util.Random;
public class Blackjack {
	
       public static void main(String[] args) {
    		   	Random random = new Random();
    		    int generated = random.nextInt(4);
    		    System.out.println("RNG test:" + generated);
    	  String name;
          int HP;
          int dealerHP;
          int bet;            
          boolean userWins; 
          String Suit;
         
          System.out.println("Welcome to the game of blackjack.");
          System.out.println();
          System.out.println("What shall your character be named?");
          Scanner scnr = new Scanner(System.in);
          name = scnr.next();
          System.out.println();
          System.out.println("RNG test:" + generated);
          System.out.println("What suit would you like? (Clubs, Spades, Hearts, or Diamonds)");
          System.out.println("*note: will not affect the appearance of cards.");
          Suit = scnr.next();
          System.out.println();
          System.out.println("RNG test:" + generated);
          int m = 0;
          while (m == 0){
          if (Suit.equals("Clubs")){
        	  System.out.println("You are Clubs. You have a weakness against Hearts and advantage against Diamonds.");
        	  System.out.println();
        	  m = 1;
          } else if (Suit.equals("Spades")){
        	  System.out.println("You are Spades. You have a weakness against Diamonds and advantage against Hearts.");
        	  System.out.println();
        	  m = 1;
          } else if (Suit.equals("Hearts")){
        	  System.out.println("You are Hearts. You have a weakness against Spades and advantage against Clubs.");
        	  System.out.println();
        	  m = 1;
          } else if (Suit.equals("Diamonds")){
        	  System.out.println("You are Diamonds. You have a weakness against Clubs and advantage against Spades.");
        	  System.out.println();
        	  m = 1;
          }else {
        	  System.out.println("Invalid Suit. Please captialize your first letter!");
        	  Suit =scnr.next();
        	  if (Suit.equals("Clubs")){
            	  System.out.println("You are Clubs. You have a weakness against Hearts and advantage against Diamonds.");
            	  System.out.println();
            	  m = 1;
              } else if (Suit.equals("Spades")){
            	  System.out.println("You are Spades. You have a weakness against Diamonds and advantage against Hearts.");
            	  System.out.println();
            	  m = 1;
              } else if (Suit.equals("Hearts")){
            	  System.out.println("You are Hearts. You have a weakness against Spades and advantage against Clubs.");
            	  System.out.println();
            	  m = 1;
              } else if (Suit.equals("Diamonds")){
            	  System.out.println("You are Diamonds. You have a weakness against Clubs and advantage against Spades.");
            	  System.out.println();
            	  m = 1;
          }
          }
          } 
         /** dealerSuit deal;
          deal = new dealerSuit();**/
          if  (generated == 0){
        	  String dealersuit = "Clubs" ;
        	  System.out.println("Dealer has the Suit of " + dealersuit);
          } else if (generated == 1) {
        	  String dealersuit = "Spades";
        	  System.out.println("Dealer has the Suit of " + dealersuit);
          } else if (generated == 2) {
        	  String dealersuit = "Hearts";
        	  System.out.println("Dealer has the Suit of " + dealersuit);
          } else if (generated == 3) {
        	  String dealersuit = "Diamonds";
        	  System.out.println("Dealer has the Suit of " + dealersuit); 
          }

          /*HP = 100;
         /* public int getHP(){
        	  return HP;
          }
          dealerHP = 100;*/
          boolean advantage = false;
          boolean userAdvantage = false;
          if ((generated == 0) && (Suit == "Diamonds")) {
        	 HP = 100;
        	 dealerHP = 150;
           advantage = true;
           userAdvantage = false;
          } else if ((generated == 3) && (Suit == "Spades")) {
         	 HP = 100;
         	 dealerHP = 150;
         	advantage = true;
         	userAdvantage = false;
           } else if ((generated == 1) && (Suit == "Hearts")) {
          	 HP = 100;
          	 dealerHP = 150;
          	advantage = true;
          	userAdvantage = false;
            }  else if ((generated == 2) && (Suit == "Clubs")) {
             	 HP = 100;
              	 dealerHP = 150;
              	advantage = true;
              	userAdvantage = false;
                } else if ((Suit == "Clubs") && (generated == 3)) {
         	 HP = 150;
         	 dealerHP = 100;
         	advantage = false;
         	userAdvantage = true;
           } else if ((Suit == "Diamonds") && (generated == 1)) {
          	 HP = 150;
          	 dealerHP = 100;
          	advantage = false;
          	userAdvantage = true;
            } else if ((Suit == "Spades") && (generated == 2)) {
           	 HP = 150;
           	 dealerHP = 100;
           	advantage = false;
          	userAdvantage = true;
             }  else if ((Suit == "Hearts") && (generated == 0)) {
              	 HP = 150;
               	 dealerHP = 100;
               	advantage = false;
               	userAdvantage = true;
                 } else {
                 	HP = 100;
                 	dealerHP = 100;
                 	advantage = false;
                  	userAdvantage = false;
                 }
          if ((advantage == true) && (userAdvantage == false)){
        	  System.out.println("Dealer has the Suit advantage!!!");
          } else if ((userAdvantage == true) && (advantage == false)){
        	  System.out.println(name + " has the Suit Advantage!!!");
          } else {
        	  System.out.println("No Suit advantage is at play!!!");
          }
          while (true) {
        	  System.out.println("You have " + HP + " HP.");
        	  System.out.println("Dealer has " + dealerHP + " HP.");
              do {
            	  System.out.println("How many Hit points do you want to bet?  (Enter 0 to end.)");
            	  System.out.println("? ");
                 
                		bet = scnr.nextInt();
                 if (bet < 0 || bet > HP)
                	 System.out.println("Your answer must be between 0 and " + HP + '.');
              } while (bet < 0 || bet > HP);
              if (bet == 0)
                 break;
              userWins = playBlackjack();
              if (userWins) {
              dealerHP = dealerHP - bet;
              } else
            	  HP = HP - bet;
             
              
              System.out.println();
              if (HP == 0) {
            	  System.out.println("Looks like you've died!");
                 break;
              }
              if (dealerHP == 0){
            	  System.out.println("Dealer is too dead to continue...");
            	  break;
              }
          }
          if (HP > 0){
          System.out.println();
          System.out.println(name + " leaves with " + HP + " HP.");
          } else {
        	  System.out.println();
        	  System.out.println(name +" cannot continue...");
          }
       if(HP >= 100){
    	   System.out.println();
    	   System.out.println("I'm surprised you still have some semblance of"
    	   		+ " Health, " + name +"...Good work!");
       }
       } 
       
       
       static boolean playBlackjack() {
            
          Deck deck;                  
          BlackjackHand dealerHand;   
          BlackjackHand userHand;    
          //Trump trumpCard;
          deck = new Deck();
          dealerHand = new BlackjackHand();
          userHand = new BlackjackHand();
          //trumpCard = new Trump();
    
          
          
          deck.shuffle();
          dealerHand.addCard( deck.dealCard() );
          dealerHand.addCard( deck.dealCard() );
          userHand.addCard( deck.dealCard() );
          userHand.addCard( deck.dealCard() );
          
          System.out.println();
          System.out.println();
          
          
          
          if (dealerHand.getBlackjackValue() == 21) {
        	  System.out.println("Dealer has the " + dealerHand.getCard(0)
                                       + " and the " + dealerHand.getCard(1) + ".");
        	  System.out.println(" You have the " + userHand.getCard(0)
                                         + " and the " + userHand.getCard(1) + ".");
        	  System.out.println();
        	  System.out.println("Dealer has Blackjack.  Dealer wins.");
               return false;
          }
          
          if (userHand.getBlackjackValue() == 21) {
        	  System.out.println("Dealer has the " + dealerHand.getCard(0)
                                       + " and the " + dealerHand.getCard(1) + ".");
        	  System.out.println("You have the " + userHand.getCard(0)
                                         + " and the " + userHand.getCard(1) + ".");
        	  System.out.println();
        	  System.out.println("You have a Blackjack.  You win.");
               return true;
          }
          
        
          
          while (true) {
              
              
        	  System.out.println();
        	  System.out.println();
        	  System.out.println("Your cards are:");
               for ( int i = 0; i < userHand.getCardCount(); i++ )
            	   System.out.println("    " + userHand.getCard(i));
               System.out.println("Your total is " + userHand.getBlackjackValue());
               System.out.println();
               System.out.println("Dealer is showing the " + dealerHand.getCard(0));
               System.out.println();
               System.out.println("Hit (H), Trump Card(T), or Stand (S)? ");
               Scanner scnr = new Scanner(System.in);
               String check = scnr.next();
               while (!check.equals("H") && !check.equals ("S") && !check.equals("T")){
                  if (!check.equals("H") && !check.equals ("S")  /*&& !check.equals("T")*/) {
                	  System.out.println("Please respond H, T, or S:  ");
                	  check = scnr.next(); 
                  }
               } 
               if ( check.equals("S") ) {
                       break;
            	   
               }/*else if (check.equals("T")){
            	 System.out.println("you have the Trump Card, " + trumpCard + ", do you wish to use it?");
            	 String trumpUse = scnr.next();  
               }*/ else  {  
                   Card newCard = deck.dealCard();
                   userHand.addCard(newCard);
                   System.out.println();
                   System.out.println("You hit.");
                   System.out.println("Your card is the " + newCard);
                   System.out.println("Your total is now " + userHand.getBlackjackValue());
                   if (userHand.getBlackjackValue() > 21) {
                	   System.out.println();
                	   System.out.println("You busted by going over 21.  You lose.");
                	   System.out.println("Dealer's other card was the " 
                                                          + dealerHand.getCard(1));
                	   return false;  
                   }
               }
                   
          }
    
          System.out.println();
          System.out.println("You stand.");
          System.out.println("Dealer's cards are");
          System.out.println("    " + dealerHand.getCard(0));
          System.out.println("    " + dealerHand.getCard(1));
          while (dealerHand.getBlackjackValue() <= 16) {
             Card newCard = deck.dealCard();
             System.out.println("Dealer hits and gets the " + newCard);
             dealerHand.addCard(newCard);
             if (dealerHand.getBlackjackValue() > 21) {
            	 System.out.println();
            	 System.out.println("Dealer busted by going over 21.  You win.");
                return true;
             }
          }
          System.out.println("Dealer's total is " + dealerHand.getBlackjackValue());
          
        
          
          System.out.println();
          if (dealerHand.getBlackjackValue() == userHand.getBlackjackValue()) {
        	  System.out.println("Dealer wins on a tie.  You lose.");
             return false;
          }
          else if (dealerHand.getBlackjackValue() > userHand.getBlackjackValue()) {
        	  System.out.println("Dealer wins, " + dealerHand.getBlackjackValue() 
                              + " points to " + userHand.getBlackjackValue() + ".");
             return false;
          }
          else {
        	  System.out.println("You win, " + userHand.getBlackjackValue() 
                              + " points to " + dealerHand.getBlackjackValue() + ".");
             return true;
          }
    
       }  
    
    
    } 