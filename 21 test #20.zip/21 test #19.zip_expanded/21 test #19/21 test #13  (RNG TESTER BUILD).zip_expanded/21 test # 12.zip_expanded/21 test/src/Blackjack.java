import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.Random;
public class Blackjack {
	
       public static void main(String[] args) {
    		   	Random random = new Random();
    		    int generated = random.nextInt(4);
    		    Random ran = new Random();
    		    int trump = ran.nextInt(3);
    		    System.out.println("RNG test");
    		    try {
					TimeUnit.MILLISECONDS.sleep(900);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
    		    if (generated < 0 && trump < 0){
        		    System.out.println("RNG failed, wouldn't reccomend playing.");
        		   
    		    } else {
    		    	System.out.println("RNG is up and running perfectly! ^v^");
    		    	System.out.println();
    		    	System.out.println();
    		    }
    		    try {
					TimeUnit.MILLISECONDS.sleep(900);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
    		    String name;
    	          int HP;
    	          int dealerHP;
    	          int bet;            
    	          boolean userWins; 
    	          String Suit;
    	         
    	          System.out.println("Welcome to the game of 21, traveller.");
    	        
    	          System.out.println("What is your name?");
    	          Scanner scnr = new Scanner(System.in);
    	          name = scnr.next();
    	          try {
  					TimeUnit.SECONDS.sleep(2);
  				} catch (InterruptedException e) {
  					e.printStackTrace();
  				}
    	          String trumpCard;
    	          int n = 0;
    	          while (n == 0){
    	        	  if (trump == 0){
    	        		trumpCard = "Death Helm";
    	        		System.out.println("You have the Trump Card " + trumpCard + ", which lowers your health instantly");
    	        		System.out.println("because you just had to test if it looked cool on you. Now it's stuck, good job dumdum!");
    	        		System.out.println();
    	        		n = 1;
    	        	  } else if (trump == 1){
    	        		  trumpCard = "Potato";
    	        		  
    	        		System.out.println("You have the Trump Card "+ trumpCard + ", which is amazing yes, but does nothing to game play. ");
    	        		System.out.println();
    	        		n = 1;
    	        	  }  else if (trump == 2){
    	        		  trumpCard = "All Work and no Fun";
    	        		  System.out.println("You have the Trump Card "+ trumpCard + ", which lowers your opponent's health by 50, instantly,");
    	        		 System.out.println("because they were up all night last night shuffling decks, so they don't exactly feel great, the idiot...");
    	        		 System.out.println();
    	        		 n = 1;
    	        	  }  
    	          }
    	          try {
    					TimeUnit.SECONDS.sleep(4);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	          System.out.println("What suit would you like? (Clubs, Spades, Hearts, or Diamonds)");
    	          System.out.println("*note: will not affect the appearance of cards.");
    	          Suit = scnr.next();
    	          System.out.println();
    	          
    	          int m = 0;
    	          while (m == 0){
    	          if (Suit.equals("Clubs")){
    	        	  System.out.println("You are Clubs. You have a weakness against Hearts and advantage against Diamonds.");
    	        	  System.out.println();
    	        	  m = 1;
    	          } else if (Suit.equals("Spades")){
    	        	  System.out.println("You are Spades. You have a weakness against Diamonds and advantage against Hearts.");
    	        	  System.out.println();
    	        	  m = 1;
    	          } else if (Suit.equals("Hearts")){
    	        	  System.out.println("You are Hearts. You have a weakness against Spades and advantage against Clubs.");
    	        	  System.out.println();
    	        	  m = 1;
    	          } else if (Suit.equals("Diamonds")){
    	        	  System.out.println("You are Diamonds. You have a weakness against Clubs and advantage against Spades.");
    	        	  System.out.println();
    	        	  m = 1;
    	          }else {
    	        	  System.out.println("Invalid Suit. Please captialize your first letter!");
    	        	  Suit =scnr.next();
    	        	  if (Suit.equals("Clubs")){
    	            	  System.out.println("You are Clubs. You have a weakness against Hearts and advantage against Diamonds.");
    	            	  System.out.println();
    	            	  m = 1;
    	              } else if (Suit.equals("Spades")){
    	            	  System.out.println("You are Spades. You have a weakness against Diamonds and advantage against Hearts.");
    	            	  System.out.println();
    	            	  m = 1;
    	              } else if (Suit.equals("Hearts")){
    	            	  System.out.println("You are Hearts. You have a weakness against Spades and advantage against Clubs.");
    	            	  System.out.println();
    	            	  m = 1;
    	              } else if (Suit.equals("Diamonds")){
    	            	  System.out.println("You are Diamonds. You have a weakness against Clubs and advantage against Spades.");
    	            	  System.out.println();
    	            	  m = 1;
    	          }
    	          }
    	          } 
    	          try {
    					TimeUnit.SECONDS.sleep(3);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	         /** dealerSuit deal;
    	          deal = new dealerSuit();**/
    	          if  (generated == 0){
    	        	  String dealersuit = "Clubs" ;
    	        	  System.out.println("Dealer has the Suit of " + dealersuit);
    	          } else if (generated == 1) {
    	        	  String dealersuit = "Spades";
    	        	  System.out.println("Dealer has the Suit of " + dealersuit);
    	          } else if (generated == 2) {
    	        	  String dealersuit = "Hearts";
    	        	  System.out.println("Dealer has the Suit of " + dealersuit);
    	          } else if (generated == 3) {
    	        	  String dealersuit = "Diamonds";
    	        	  System.out.println("Dealer has the Suit of " + dealersuit); 
    	          }
    	          try {
    					TimeUnit.SECONDS.sleep(2);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	          /*HP = 100;
    	         /* public int getHP(){
    	        	  return HP;
    	          }
    	          dealerHP = 100;*/
    	          boolean advantage = false;
    	          boolean userAdvantage = false;
    	          boolean trumpAdvantage = false;
    	          boolean dealTrump = false;
    	          if (generated == 0 && Suit.equals("Diamonds")) {
    	        	  if (trump == 2){
    	        		  HP = 100;
    	        		  dealerHP = 100;
    	        		  advantage = true;
    	        		  userAdvantage = false;
    	        		  trumpAdvantage = true;
    	        	  } else if (trump == 0) {
    	        		  HP = 50;
    	        		  dealerHP = 150;
    	        		  advantage = true;
    	        		  userAdvantage = false;
    	        		  dealTrump = true;
    	        	  }else {
    	        	 HP = 100;
    	        	 dealerHP = 150;
    	           advantage = true;
    	           userAdvantage = false;
    	        	  }   	  
    	          } else if (generated == 3 && Suit.equals("Spades")) {
    	        	  if (trump == 2){
    	        		  HP = 100;
    	        		  dealerHP = 100;
    	        		  advantage = true;
    	        		  userAdvantage = false;
    	        		  trumpAdvantage = true;
    	        	  }else if (trump == 0) {
    	        		  HP = 50;
    	        		  dealerHP = 150;
    	        		  advantage = true;
    	        		  userAdvantage = false;
    	        		  dealTrump = true;
    	        	  } else {
    	        	 HP = 100;
    	        	 dealerHP = 150;
    	           advantage = true;
    	           userAdvantage = false;
    	        	  }
    	           } else if (generated == 1 && Suit.equals("Hearts")) {
    	        	   if (trump == 2){
     	        		  HP = 100;
     	        		  dealerHP = 100;
     	        		  advantage = true;
     	        		  userAdvantage = false;
     	        		  trumpAdvantage = true;
     	        	  } else if (trump == 0) {
    	        		  HP = 50;
    	        		  dealerHP = 150;
    	        		  advantage = true;
    	        		  userAdvantage = false;
    	        		  dealTrump = true;
    	        	  }else {
     	        	 HP = 100;
     	        	 dealerHP = 150;
     	           advantage = true;
     	           userAdvantage = false;
     	        	  }
    	            }  else if (generated == 2 && Suit.equals("Clubs")) {
    	            	if (trump == 2){
      	        		  HP = 100;
      	        		  dealerHP = 100;
      	        		  advantage = true;
      	        		  userAdvantage = false;
      	        		  trumpAdvantage = true;
      	        	  } else if (trump == 0) {
    	        		  HP = 50;
    	        		  dealerHP = 150;
    	        		  advantage = true;
    	        		  userAdvantage = false;
    	        		  dealTrump = true;
    	        	  }else {
      	        	 HP = 100;
      	        	 dealerHP = 150;
      	           advantage = true;
      	           userAdvantage = false;
      	        	  }
    	                } else if (Suit.equals("Clubs") && generated == 3) {
    	                	if (trump == 2){
    	      	        		  HP = 150;
    	      	        		  dealerHP = 50;
    	      	        		  advantage = false;
    	      	        		  userAdvantage = true;
    	      	        		  trumpAdvantage = true;
    	      	        	  } else if (trump == 0) {
    	    	        		  HP = 100;
    	    	        		  dealerHP = 100;
    	    	        		  advantage = false;
    	    	        		  userAdvantage = true;
    	    	        		  dealTrump = true;
    	    	        	  }else {
    	         	 HP = 150;
    	         	 dealerHP = 100;
    	         	advantage = false;
    	         	userAdvantage = true;
    	      	        	  }
    	           } else if (Suit.equals("Diamonds") && generated == 1) {
    	        	   if (trump == 2){
	      	        		  HP = 150;
	      	        		  dealerHP = 50;
	      	        		  advantage = false;
	      	        		  userAdvantage = true;
	      	        		  trumpAdvantage = true;
	      	        	  }  else if (trump == 0) {
	    	        		  HP = 100;
	    	        		  dealerHP = 100;
	    	        		  advantage = false;
	    	        		  userAdvantage = true;
	    	        		  dealTrump = true;
	    	        	  }else {
	         	 HP = 150;
	         	 dealerHP = 100;
	         	advantage = false;
	         	userAdvantage = true;
	      	        	  }
    	            } else if (Suit.equals("Spades") && generated == 2) {
    	            	if (trump == 2){
	      	        		  HP = 150;
	      	        		  dealerHP = 50;
	      	        		  advantage = false;
	      	        		  userAdvantage = true;
	      	        		  trumpAdvantage = true;
	      	        	  }  else if (trump == 0) {
	    	        		  HP = 100;
	    	        		  dealerHP = 100;
	    	        		  advantage = false;
	    	        		  userAdvantage = true;
	    	        		  dealTrump = true;
	    	        	  }else {
	         	 HP = 150;
	         	 dealerHP = 100;
	         	advantage = false;
	         	userAdvantage = true;
	      	        	  }
    	             }  else if (Suit.equals("Hearts") && generated == 0) {
    	            	 if (trump == 2){
	      	        		  HP = 150;
	      	        		  dealerHP = 50;
	      	        		  advantage = false;
	      	        		  userAdvantage = true;
	      	        		  trumpAdvantage = true;
	      	        	  }  else if (trump == 0) {
	    	        		  HP = 100;
	    	        		  dealerHP = 100;
	    	        		  advantage = false;
	    	        		  userAdvantage = true;
	    	        		  dealTrump = true;
	    	        	  }else {
	         	 HP = 150;
	         	 dealerHP = 100;
	         	advantage = false;
	         	userAdvantage = true;
	      	        	  }
    	                 } else {
    	                	 if (trump == 2){
   	      	        		  HP = 100;
   	      	        		  dealerHP = 50;
   	      	        		  advantage = false;
   	      	        		  userAdvantage = false;
   	      	        		  trumpAdvantage = true;
   	      	        	  }  else if (trump == 0) {
	    	        		  HP = 100;
	    	        		  dealerHP = 100;
	    	        		  advantage = false;
	    	        		  userAdvantage = true;
	    	        		  dealTrump = true;
	    	        	  }else {
    	                 	HP = 100;
    	                 	dealerHP = 100;
    	                 	advantage = false;
    	                  	userAdvantage = false;
   	      	        	  }
    	                 }
    	          if (advantage == true && userAdvantage == false){
    	        	  System.out.println("Dealer has the Suit advantage!!!");
    	          } else if (userAdvantage == true && advantage == false){
    	        	  System.out.println(name + " has the Suit Advantage!!!");
    	          } else if (dealTrump == true && userAdvantage == false && advantage == false) {
    	        	  System.out.println("No Suit advantage is at play but " + name + "'s Trump Card effect give the dealer the edge!!!");
    	          
    	        	  try {
      					TimeUnit.SECONDS.sleep(5);
      				} catch (InterruptedException e) {
      					e.printStackTrace();
      				}
    	        	  } else {
    	        	  System.out.println("No Suit advantage or Trump Card advantage is at play!!!");
    	          }
    	          try {
    					TimeUnit.SECONDS.sleep(5);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	          while (true) {
    	        	  System.out.println("You have " + HP + " HP.");
    	        	  System.out.println("Dealer has " + dealerHP + " HP.");
    	              do {
    	            	  System.out.println("How many Hit points do you want to bet?  (Enter 0 to end.)");
    	            	 
    	                 
    	                		bet = scnr.nextInt();
    	                 if (bet < 0 || bet > HP)
    	                	 System.out.println("Your answer must be between 0 and " + HP + '.');
    	              } while (bet < 0 || bet > HP);
    	              if (bet == 0)
    	                 break;
    	              userWins = playBlackjack();
    	              if (userWins) {
    	            		  dealerHP = dealerHP - bet;
    	              } else {            	  
    	            	  HP = HP - bet;            	  
    	              }
    	              
    	              System.out.println();
    	              if (HP == 0) {
    	            	  System.out.println("Looks like you've died!");
    	            	  try {
    	      				TimeUnit.SECONDS.sleep(1);
    	      			} catch (InterruptedException e) {
    	      				e.printStackTrace();
    	      			}
    	                 break;
    	              }
    	              if (dealerHP == 0){
    	            	  System.out.println("Dealer is too dead to continue...");
    	            	  try {
    	      				TimeUnit.SECONDS.sleep(1);
    	      			} catch (InterruptedException e) {
    	      				e.printStackTrace();
    	      			}
    	            	  break;
    	              }
    	          }
    	          if (HP > 0){
    	          System.out.println();
    	          System.out.println(name + " leaves with " + HP + " HP.");
    	          try {
    					TimeUnit.SECONDS.sleep(1);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	          } else {
    	        	  System.out.println();
    	        	  System.out.println(name +" cannot continue...");
    	        	  try {
    	    				TimeUnit.SECONDS.sleep(1);
    	    			} catch (InterruptedException e) {
    	    				e.printStackTrace();
    	    			}
    	          }
    	       if(HP >= 100){
    	    	   try {
    					TimeUnit.SECONDS.sleep(1);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	    	   System.out.println("I'm surprised you still have some semblance of"
    	    	   		+ " Health, " + name +"...Good work!");
    	       }
    	       if (HP <= 20 && HP != 0){
    	    	   try {
    					TimeUnit.SECONDS.sleep(1);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	    	   System.out.println();
    	    	   System.out.println("Barely made it out with the skin of your teeth huh, " + name + "?");
    	       }
    	       } 
    	       
    	       
    	       static boolean playBlackjack() {
    	            
    	          Deck deck;                  
    	          BlackjackHand dealerHand;   
    	          BlackjackHand userHand;    
    	          //Trump trumpCard;
    	          deck = new Deck();
    	          dealerHand = new BlackjackHand();
    	          userHand = new BlackjackHand();
    	          //trumpCard = new Trump();
    	    
    	          
    	          
    	          deck.shuffle();
    	          dealerHand.addCard( deck.dealCard() );
    	          dealerHand.addCard( deck.dealCard() );
    	          userHand.addCard( deck.dealCard() );
    	          userHand.addCard( deck.dealCard() );
    	          
    	          System.out.println();
    	          System.out.println();
    	          
    	          
    	          
    	          if (dealerHand.getBlackjackValue() == 21) {
    	        	  System.out.println("Dealer has the " + dealerHand.getCard(0)
    	                                       + " and the " + dealerHand.getCard(1) + ".");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(2);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	        	  System.out.println(" You have the " + userHand.getCard(0)
    	                                         + " and the " + userHand.getCard(1) + ".");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(2);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	        	  System.out.println("Dealer has Blackjack.  Dealer wins.");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(3);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	               return false;
    	               
    	          }
    	          
    	          if (userHand.getBlackjackValue() == 21) {
    	        	  System.out.println("Dealer has the " + dealerHand.getCard(0)
    	                                       + " and the " + dealerHand.getCard(1) + ".");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(2);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	        	  System.out.println("You have the " + userHand.getCard(0)
    	                                         + " and the " + userHand.getCard(1) + ".");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(2);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	        	  System.out.println("You have a Blackjack.  You win.");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(2);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	               return true;
    	          }
    	          
    	        
    	          
    	          while (true) {
    	              
    	              
    	        	 
    	        	  System.out.println("Your cards are:");
    	               for ( int i = 0; i < userHand.getCardCount(); i++ )
    	            	   System.out.println("    " + userHand.getCard(i));
    	               try {
    	      				TimeUnit.SECONDS.sleep(3);
    	      			} catch (InterruptedException e) {
    	      				e.printStackTrace();
    	      			}
    	               System.out.println("Your total is " + userHand.getBlackjackValue());
    	               try {
    	   				TimeUnit.SECONDS.sleep(3);
    	   			} catch (InterruptedException e) {
    	   				e.printStackTrace();
    	   			}
    	               System.out.println("Dealer is showing the " + dealerHand.getCard(0));
    	               try {
    	   				TimeUnit.SECONDS.sleep(3);
    	   			} catch (InterruptedException e) {
    	   				e.printStackTrace();
    	   			}
    	               System.out.println("Hit (H) or Stand (S)? ");
    	               Scanner scnr = new Scanner(System.in);
    	               String check = scnr.next();
    	               while (!check.equals("H") && !check.equals ("S") && !check.equals("T")){
    	                  if (!check.equals("H") && !check.equals ("S")  /*&& !check.equals("T")*/) {
    	                	  System.out.println("Please respond H or S:  ");
    	                	  check = scnr.next(); 
    	                  }
    	               } 
    	               if ( check.equals("S") ) {
    	                       break;
    	            	   
    	               }/*else if (check.equals("T")){
    	            	 System.out.println("you have the Trump Card, " + trumpCard + ", do you wish to use it?");
    	            	 String trumpUse = scnr.next();  
    	               }*/ else  {  
    	                   Card newCard = deck.dealCard();
    	                   userHand.addCard(newCard);
    	                   System.out.println();
    	                   System.out.println("You hit.");
    	                   try {
    	       				TimeUnit.SECONDS.sleep(1);
    	       			} catch (InterruptedException e) {
    	       				e.printStackTrace();
    	       			}
    	                   System.out.println("Your card is the " + newCard);
    	                   try {
    	       				TimeUnit.SECONDS.sleep(2);
    	       			} catch (InterruptedException e) {
    	       				e.printStackTrace();
    	       			}
    	                   System.out.println("Your total is now " + userHand.getBlackjackValue());
    	                   try {
    	       				TimeUnit.SECONDS.sleep(2);
    	       			} catch (InterruptedException e) {
    	       				e.printStackTrace();
    	       			}
    	                   if (userHand.getBlackjackValue() > 21) {
    	                	 
    	                	   System.out.println("You busted by going over 21.  You lose.");
    	                	   System.out.println("Dealer's other card was the " 
    	                                                          + dealerHand.getCard(1));
    	                	   try {
    	           				TimeUnit.SECONDS.sleep(4);
    	           			} catch (InterruptedException e) {
    	           				e.printStackTrace();
    	           			}
    	                	   return false;  
    	                   }
    	               }
    	                   
    	          }
    	    
    	          System.out.println();
    	          System.out.println("You stand.");
    	          System.out.println("Dealer's cards are");
    	          System.out.println("    " + dealerHand.getCard(0));
    	          System.out.println("    " + dealerHand.getCard(1));
    	          try {
    					TimeUnit.SECONDS.sleep(2);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	          while (dealerHand.getBlackjackValue() <= 16) {
    	             Card newCard = deck.dealCard();
    	             System.out.println("Dealer hits and gets the " + newCard);
    	             try {
    	 				TimeUnit.SECONDS.sleep(2);
    	 			} catch (InterruptedException e) {
    	 				e.printStackTrace();
    	 			}
    	             dealerHand.addCard(newCard);
    	             if (dealerHand.getBlackjackValue() > 21) {
    	            	
    	            	 System.out.println("Dealer busted by going over 21.  You win.");
    	            	 try {
    	     				TimeUnit.SECONDS.sleep(3);
    	     			} catch (InterruptedException e) {
    	     				e.printStackTrace();
    	     			}
    	                return true;
    	             }
    	          }
    	          System.out.println("Dealer's total is " + dealerHand.getBlackjackValue());
    	          try {
    					TimeUnit.SECONDS.sleep(2);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}
    	          
    	        
    	          
    	          System.out.println();
    	          if (dealerHand.getBlackjackValue() == userHand.getBlackjackValue()) {
    	        	  System.out.println("Dealer wins on a tie.  You lose.");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(2);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	             return false;
    	          }
    	          else if (dealerHand.getBlackjackValue() > userHand.getBlackjackValue()) {
    	        	  System.out.println("Dealer wins, " + dealerHand.getBlackjackValue() 
    	                              + " points to " + userHand.getBlackjackValue() + ".");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(2);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	             return false;
    	          }
    	          else {
    	        	  System.out.println("You win, " + userHand.getBlackjackValue() 
    	                              + " points to " + dealerHand.getBlackjackValue() + ".");
    	        	  try {
    	  				TimeUnit.SECONDS.sleep(2);
    	  			} catch (InterruptedException e) {
    	  				e.printStackTrace();
    	  			}
    	             return true;
    	          }
    	    
    	       }  
    	    
    	    
    	    }