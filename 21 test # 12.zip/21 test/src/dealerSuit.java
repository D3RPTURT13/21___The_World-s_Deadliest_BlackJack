import java.util.Random;

public class dealerSuit {
	public static int randomSuit(){
	   	Random random = new Random();
	    int generated = random.nextInt(3);
	    System.out.println(generated);
	    return generated;     
	}
}
