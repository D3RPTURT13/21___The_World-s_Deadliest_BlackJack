package randomTest;

public class main {
	  public static dealerSuit main(String[] args) {
		  dealerSuit suit;
		  suit = new dealerSuit();
		  return suit;
	  }
}
