import java.util.Random;
import java.util.ArrayList;
public class Trump {
	
String trump;
public static int generateBetween() {
   	Random random = new Random();
    int generated = random.nextInt(7);
    if (generated > 0){
    	if (generated <= 7){
    return generated;
    }
    } else {
    	while(false){
    		generated = random.nextInt(7);
    		 if (generated > 0){
    		    	if (generated <= 7){
    		    return generated;
    		    return true;
    		    } 	
    	} else 
    		return false;
    	}
    }
}

}

